async function cadastrar(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const nomeCompleto = document.getElementById('nome').value;
    const senha = document.getElementById('senha').value;

    const data = { email, nomeCompleto, senha };

    try {
        const response = await fetch('http://localhost:3000/usuario/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const results = await response.json();

        if (response.ok) {
            if (results.success) {
                alert('Usuário cadastrado com sucesso!');
            } else {
                alert('Erro: ' + results.message);
            }
        } else {
            alert('Erro ao cadastrar: ' + results.message);
        }
    } catch (error) {
        console.error('Erro ao tentar cadastrar:', error);
        alert('Ocorreu um erro ao tentar cadastrar. Tente novamente.');
    }
}
