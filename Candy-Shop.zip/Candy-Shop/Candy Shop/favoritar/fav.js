document.addEventListener('DOMContentLoaded', () => {
    const favoriteContainer = document.querySelector('.favorite-container');

    function loadFavorites() {
        const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        const products = [
            { id: 1, name: 'POÇÃO DA INVISIBILIDADE', price: 99, image: '../fotos/Prod1.jpeg' },
            { id: 2, name: 'NUVENS DA LEVITAÇÃO', price: 49, image: '../fotos/prod2.png' },
            { id: 3, name: 'BEIJOS ALIENÍGENAS', price: 60, image: '../fotos/prod3.jpeg' },
            { id: 4, name: 'UNICÓRNIOS DA CURA', price: 32, image: '../fotos/prod4.png' },
            { id: 5, name: 'BISCOITO ESTATURA', price: 55, image: '../fotos/prod5.png' },
            { id: 6, name: 'GOMAS DA FORÇA', price: 79, image: '../fotos/prod6.jpeg' },
            { id: 7, name: 'MARSHMALLOWS DO TELETRANSPORTE', price: 59, image: '../fotos/prod7.jpeg' },
            { id: 8, name: 'CUPCAKES DA TELEPATIA', price: 29, image: '../fotos/prod8.png' }
        ];

        favoriteContainer.innerHTML = '';

        if (favorites.length === 0) {
            favoriteContainer.innerHTML = '<p>Nenhum produto favoritado.</p>';
            return;
        }

        favorites.forEach(productId => {
            const product = products.find(p => p.id === productId);
            if (product) {  // Garante que o produto existe
                const favoriteItem = document.createElement('div');
                favoriteItem.className = 'favorite-product';
                favoriteItem.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <p>R$ ${product.price}</p>
                    <button onclick="removeFromFavorites(${product.id})">Remover dos Favoritos</button>
                `;
                favoriteContainer.appendChild(favoriteItem);
            }
        });
    }

    function removeFromFavorites(productId) {
        let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        favorites = favorites.filter(id => id !== productId);
        localStorage.setItem('favorites', JSON.stringify(favorites));
        loadFavorites();
    }

    window.removeFromFavorites = removeFromFavorites;

    loadFavorites();
});
