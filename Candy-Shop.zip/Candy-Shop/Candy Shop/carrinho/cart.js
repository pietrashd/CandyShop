document.addEventListener('DOMContentLoaded', () => {
    const cartContainer = document.querySelector('.cart-container');
    const totalPriceElement = document.querySelector('.total-price');
    const checkoutButton = document.getElementById('checkout-button');

    const products = [
        { id: 1, name: 'POÇÃO DA INVISIBILIDADE', price: 99, image: '../fotos/Prod1.jpeg' },
        { id: 2, name: 'NUVENS DA LEVITAÇÃO', price: 49, image: '../fotos/prod2.png' },
        { id: 3, name: 'BEIJOS ALIENÍGENAS', price: 60, image: '../fotos/prod3.jpeg' },
        { id: 4, name: 'UNICÓRNIOS DA CURA', price: 32, image: '../fotos/prod4.png' },
        { id: 5, name: 'BISCOITO ESTATURA', price: 55, image: '../fotos/prod5.png' },
        { id: 6, name: 'GOMAS DA FORÇA', price: 79, image: '../fotos/prod6.jpeg' },
        { id: 7, name: 'MARSHMALLOWS DO TELETRANSPORTE', price: 59, image: '../fotos/prod7.jpeg' },
        { id: 8, name: 'CUPCAKES DA TELEPATIA', price: 29, image: '../fotos/prod8.png' }
    ];

    function loadCart() {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let totalPrice = 0;

        cartContainer.innerHTML = '';

        if (cart.length === 0) {
            cartContainer.innerHTML = '<p>O carrinho está vazio.</p>';
            totalPriceElement.style.display = 'none';
            checkoutButton.style.display = 'none';
            return;
        }

        cart.forEach(productId => {
            let product = products.find(p => p.id === productId);
            totalPrice += product.price;

            const cartItem = document.createElement('div');
            cartItem.className = 'product';
            cartItem.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="prod-det">
                    <h3>${product.name}</h3>
                    <p>R$ ${product.price}</p>
                    <button onclick="removeFromCart(${product.id})"><i class="bi bi-cart-dash-fill"></i></button>
                </div>
            `;

            cartContainer.appendChild(cartItem);
        });

        totalPriceElement.textContent = `Total: R$ ${totalPrice}`;
        totalPriceElement.style.display = 'block';
        checkoutButton.style.display = 'block';
    }

    function removeFromCart(productId) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        cart = cart.filter(id => id !== productId);
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCart();
    }

    window.removeFromCart = removeFromCart;

    function clearCart() {
        localStorage.removeItem('cart');
        loadCart();
    }

    window.clearCart = clearCart;

    function showPurchaseForm() {
        document.querySelector('.purchase-form').style.display = 'block';
    }

    window.showPurchaseForm = showPurchaseForm;

    function submitPurchaseForm(event) {
        event.preventDefault();
        alert('Compra finalizada com sucesso!');
        clearCart();
        document.querySelector('.purchase-form').style.display = 'none';
    }

    window.submitPurchaseForm = submitPurchaseForm;

    loadCart(); // Carrega o carrinho ao abrir a página
});
