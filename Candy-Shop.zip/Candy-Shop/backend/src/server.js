const express = require('express');
const cors = require('cors');
//definir a porta
const porta = 3000;
const app = express();
//habilitar o cors e utilizar json
app.use(cors());
app.use(express.json());
//testar
app.listen(porta, () => console.log(`rodando na porta` + porta));


const connection = require('./db_config.js');


app.post('/usuario/cadastrar', (request, response) => {
    // criar um array com dados recebidos
    let params = Array(
        request.body.email,
        request.body.nomeCompleto,
        request.body.senha
    );
    // criar o comando de execução no banco de dados
    let query = "INSERT INTO usuario(email, nomeCompleto, senha) VALUES(?,?,?);";
    // passar o comando e os dados para a função query
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(201)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    menssage: "sem sucesso",
                    data: err
                })
        }
    })
});

app.get('/usuario/listar', (request, response) => {
    const query = "SELECT * FROM usuario";

    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});


app.put('/usuario/editar/:id', (request, response) => {

    let params = [
        request.body.nomeCompleto,
        request.body.senha,
        request.params.id
    ];


    let query = "UPDATE usuario SET email = ?, senha = ? WHERE id_usuario = ?;";


    connection.query(query, params, (err, results) => {
        if (err) {

            return response.status(400).json({
                success: false,
                message: "Erro na atualização dos daods",
                data: err
            });
        }


        response.status(200).json({
            success: true,
            message: "Dados atualizadoscom sucesso",
            data: results
        });
    });
});

app.delete('/usuario/deletar/:id', (request, response) => {
    let id = request.params.id;

    let query = "DELETE FROM usuario WHERE id_usuario = ?;"

    connection.query(query, [id], (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});


// ROTAS PARA A PAGINA DE CADASTRO DE PRODUTOS


app.post('/produtos/cadastrar', (request, response) => {
    // criar um array com dados recebidos
    let params = Array(
        request.body.nomeProduto,
        request.body.preco,
        request.body.descricao
    );
    // criar o comando de execução no banco de dados
    let query = "INSERT INTO produtos(nomeProduto, preco, descricao) VALUES(?,?,?);";
    // passar o comando e os dados para a função query
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(201)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    menssage: "sem sucesso",
                    data: err
                })
        }
    })
});

app.get('/produtos/listar', (request, response) => {
    const query = "SELECT * FROM produtos";

    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});

app.put('/produtos/editar/:id', (request, response) => {
    
    let params = [
        request.body.nomeProduto,
        request.body.preco,
        request.body.descricao,
        request.params.id
    ];

 
    let query = "UPDATE produtos SET nomeProduto = ?, preco = ?, descricao = ? WHERE id_produto = ?";

    
    connection.query(query, params, (err, results) => {
        if (err) {
            
            return response.status(400).json({
                success: false,
                message: "Erro na atualização dos dados",
                data: err
            });
        }

        
        response.status(200).json({
            success: true,
            message: "Dados atualizados com sucesso",
            data: results
        });
    });
});

app.delete('/produtos/deletar/:id', (request, response) => {
    let id = request.params.id;

    let query = "DELETE FROM produtos WHERE id_produto = ?;"

    connection.query(query, [id], (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});

app.post('/login', (request, response) => {
  let params = Array(
    request.body.email
  )

  let query = "SELECT email, NomeCompleto, senha, perfil FROM usuario WHERE email = ?";

  connection.query(query, params, (err, results) => {
    if(results.length > 0) {
      let senhaDigita = request.body.password
      let senhaBanco = results[0].password

      if(senhaBanco == senhaDigita) {
        response
        .status(200)
        .json({
          succes: true,
          message: "Sucesso",
          data: results[0]
        })
    } else {
        response 
        .status(400)
        .json({
          sucess: false,
          message: "Verifique sua senha!"
     })
      }
    } else {
     response 
       .status(400)
       .json({
         sucess: false,
         message: "E-mail não cadastrado!"
    })
    }
  })
})
