document.addEventListener('DOMContentLoaded', () => {
    const products = [
        { id: 1, name: 'POÇÃO DA INVISIBILIDADE', price: 99, image: 'fotos/Prod1.jpeg' },
        { id: 2, name: 'NUVENS DA LEVITAÇÃO', price: 49, image: 'fotos/prod2.png' },
        { id: 3, name: 'BEIJOS ALIENÍGENAS', price: 60, image: 'fotos/prod3.jpeg' },
        { id: 4, name: 'UNICÓRNIOS DA CURA', price: 32, image: 'fotos/prod4.png' },
        { id: 5, name: 'BISCOITO ESTATURA', price: 55, image: 'fotos/prod5.png' },
        { id: 6, name: 'GOMAS DA FORÇA', price: 79, image: 'fotos/prod6.jpeg' },
        { id: 7, name: 'MARSHMALLOWS DO TELETRANSPORTE', price: 59, image: 'fotos/prod7.jpeg' },
        { id: 8, name: 'CUPCAKES DA TELEPATIA', price: 29, image: 'fotos/prod8.png' }
    ];

    const productContainer = document.querySelector('.product-container');

    function loadProducts() {
        productContainer.innerHTML = '';

        products.forEach(product => {
            const productElement = document.createElement('div');
            productElement.className = 'product';
            productElement.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="prod-det">
                    <h3>${product.name}</h3>
                    <p>R$ ${product.price}</p>
                    <button onclick="addToCart(${product.id})"><i class="bi bi-cart-plus-fill"></i></button>
                    <button onclick="toggleFavorite(${product.id})">
                        ${isFavorite(product.id) ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}
                    </button>
                </div>
            `;
            productContainer.appendChild(productElement);
        });
    }

    function addToCart(productId) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        if (!cart.includes(productId)) {
            cart.push(productId);
            localStorage.setItem('cart', JSON.stringify(cart));
            alert('Produto adicionado ao carrinho!');
        } else {
            alert('Produto já está no carrinho.');
        }
    }

    function isFavorite(productId) {
        const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        return favorites.includes(productId);
    }

    function toggleFavorite(productId) {
        let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
        if (favorites.includes(productId)) {
            favorites = favorites.filter(id => id !== productId);
            alert('Produto removido dos favoritos.');
        } else {
            favorites.push(productId);
            alert('Produto adicionado aos favoritos.');
        }
        localStorage.setItem('favorites', JSON.stringify(favorites));
        loadProducts(); // Atualiza a lista de produtos após favoritar/desfavoritar
    }

    window.addToCart = addToCart;
    window.toggleFavorite = toggleFavorite;
    window.isFavorite = isFavorite;

    loadProducts();
});
