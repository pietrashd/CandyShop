CREATE DATABASE IF NOT EXISTS candyShop;
USE candyShop;

CREATE TABLE IF NOT EXISTS usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    NomeCompleto VARCHAR(255) NOT NULL,
    senha VARCHAR(255) NOT NULL,
    perfil ENUM('admin', 'usuario') DEFAULT 'usuario'
);

SELECT * FROM usuario;

INSERT INTO usuario (email, NomeCompleto, senha, perfil)
VALUES ('Alana@gmail.com', 'Alana', '1455', 'admin');

SELECT * FROM usuario;

UPDATE usuario SET email = 'novo_email@example.com', senha = 'nova_senha' WHERE id_usuario = 1;

SELECT * FROM usuario WHERE id_usuario = 1;

DELETE FROM usuario WHERE id_usuario = 1;

SELECT * FROM usuario;

CREATE TABLE IF NOT EXISTS produtos (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    nomeProduto VARCHAR(255) NOT NULL UNIQUE,
    preco FLOAT,
    descricao VARCHAR(1000) NOT NULL
);

INSERT INTO produtos (nomeProduto, preco, descricao)
VALUES ('Bolacha Suprema', 48, 'Bolacha que recupera saúde física e mental da pessoa');

SELECT * FROM produtos;

UPDATE produtos SET nomeProduto = 'Biscoito Supremo', preco = 90 WHERE id_produto = 1;

SELECT * FROM produtos WHERE id_produto = 1;

DELETE FROM produtos WHERE id_produto = 1;

SELECT * FROM produtos;

CREATE TABLE IF NOT EXISTS carrinho (
    id_carrinho INT PRIMARY KEY AUTO_INCREMENT,
    id_produto INT,
    id_usuario INT,
    preco_total FLOAT,
    FOREIGN KEY (id_produto) REFERENCES produtos(id_produto),
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

INSERT INTO carrinho (id_produto, id_usuario, preco_total)
VALUES (1, 1, 48);

SELECT * FROM carrinho;

CREATE TABLE IF NOT EXISTS products (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(250),
    price DOUBLE NOT NULL,
    image TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SELECT * FROM products;
